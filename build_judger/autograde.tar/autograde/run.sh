echo 123
ls -alh
cd rsdkaj
echo 123 
