import json
print(json.dumps({'scores': {"Q1": 10}}))


